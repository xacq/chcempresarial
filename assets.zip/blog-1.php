<?php 
  include('./cabecera.php');
?>
<main id="main">
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center">
      <h2>Paso a paso para el cálculo de cuotas del IMSS</h2> <!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
    </div>
  </div>
</section>
<!-- End Breadcrumbs -->

<!-- =================================== Inicio de Section para el contenido de una NOTICIA ========================================== -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center">
<!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-1.jpg" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br>
<!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
              <br>
              <h1 class="entry-title">
                <a href="#">
                  Paso a paso para el cálculo de cuotas del IMSS  <!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a> 
              </h1>
<!-- ************* AQUI COLOCO YA EL CONTENIDO DEL BLOG***************-->
              <div class="entry-content">
                <br>
                <p>

                El cálculo de cuotas del IMSS tuvo para este 2023 varios ajustes a realizar progresivamente. Las también conocidas cuotas obrero patronales
                representan el total de dinero que se aporta al Instituto Mexicano del Seguro Social (IMSS) por los trabajadores y patrones; más la cuota 
                social que aporta el gobierno mexicano.<br><br>

                Dichas aportaciones que hacen el trabajador y el patrón por ley garantizan la seguridad social y conforman un patrimonio para el retiro, 
                cesantía y vejez. En ese sentido, cada trabajador posee una cuenta individual.<br><br>

                Toda esta información periódica debe aparecer en el recibo de nómina con el concepto “IMSS” o “Seguro Social”. Aunque el cálculo requiere de 
                muchos datos y podría ser abrumador por la cantidad de colaboradores, verás que es muy sencillo. Te explicamos el paso a paso.<br>

                <h4><strong>Cuotas del IMSS o deducciones</strong></h4><br>

                El IMSS proporciona 5 coberturas a los trabajadores inscritos al seguro social:<br><br>

                <ul>  <!-- lista no ordenada -->
                  <li>Seguro de enfermedades y maternidad.</li>
                  <li>Seguro de riesgos de trabajo.</li>
                  <li>Seguro de invalidez y vida.</li>
                  <li>Seguro de retiro, cesantía en edad avanzada y vejez.</li>
                  <li>Guarderías y prestaciones sociales.</li>
                </ul>

                Entonces, las aportaciones obrero patronales cubren las primas de cada uno de estos seguros.<br><br>

                <h4><strong>¿Cuánto hay que pagar?</strong></h4><br>

                Las empresas deben calcular el Salario Base de Cotización (SBC) del empleado para el cálculo de cuotas del IMSS. <br><br>

                Además, se toma como referencia económica la Unidad de Medida de Actualización (UMA). En 2023, el valor diario de 
                la UMA es de $103,74 pesos, el valor mensual es de $3,153 pesos y el anual es de $37,844 pesos. Estas cuotas se pagan 
                entre el día 1 y 17 de cada mes (a mes vencido), no lo olvides. <br><br> 
                
                Con esos datos se determina la prima a pagar para los cinco seguros mencionados. <br> <br>

                 <h4><strong>Cómo se calculan las cuotas del IMSS a pagar</strong></h4><br>

                La forma en la que se calcula el SBC es simple. Antes de empezar, considera: <br><br>
                
                <ul>
                  <li>Salario base de cotización de cada empleado.</li>
                  <li>UMA</li>
                  <li>Porcentajes fijados por la Ley del Seguro Social en cuanto a seguros y prestaciones sociales brindados a los empleados.</li>
                </ul>  <br>

                Primero se toma el salario anual del trabajador. El SBC es lo que cobra el empleado en un día. Dentro de este pago se incluyen las horas 
                trabajadas, gratificaciones, comisiones, habitación y alimentación.
                Cuando el salario del empleado es menor al salario mínimo aplicable, se toma en consideración el valor del salario mínimo como base para 
                el cálculo de la cuota.
                Cuando el salario supera la suma de UMA por 25 veces, se considera éste como último valor para el cálculo de la cuota. <br><br>

                La fórmula para calcular el SBC es: <br><br>
                
                <div class="text-center"><strong>SBC= SALARIO DIARIO X FACTOR DE INTEGRACIÓN</strong></div><br><br>

                Para obtener el valor del salario diario se divide la suma que el empleado cobra entre la cantidad de días. 
                Para el factor de integración se considera la fórmula: <br><br>

                <div class="text-center"><strong>FACTOR DE INTEGRACIÓN: (365 DÍAS DEL AÑO+(DÍAS DE VACACIONES X 25% DE PRIMA VACACIONAL)+DÍAS DE AGUINALDO)/365 DÍAS DEL AÑO</strong></h5></div>
                
                <br>

                Ya obtenido el Salario Base de Cotización, se pasa a calcular las cuotas de la siguiente manera. <br><br>

                <h4><strong>Seguro de riesgo de trabajo</strong></h4><br>

                Determina la clase de riesgo de trabajo. Esta información aparece en el Reglamento de la ley del seguro social en materia de afiliación, clasificación de empresas, recaudación y fiscalización y las clases. <br><br>

                <table class="table text-center">
                  <thead>
                    <tr>
                      <th scope="col">PRIMA MEDIA</th>
                      <th scope="col">PORCENTAJES</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr> 
                      <td>Clase I</td>
                      <td>0.54355</td>
                    </tr>
                    <tr>
                      <td>Clase II</td>
                      <td>1.13065</td>
                    </tr>
                    <tr>
                      <td>Clase III</td>
                      <td>2.5984</td>
                    </tr>
                    <tr>
                      <td>Clase IV</td>
                      <td>4.65325</td>
                    </tr>
                    <tr>
                      <td>Clase V</td>
                      <td>7.58875</td>
                    </tr>
                  </tbody>
                </table>

                <h4><strong>Seguro de enfermedades y maternidad</strong></h4>

                La cuota fija por parte del patrón es del 20% de la UMA mensual. Para hacer los cálculos de prestaciones en dinero, se toma como 
                referencia el salario base de cotización (SBC) del trabajador. Corresponde al trabajador: 0.250% del SBC y corresponde al patrón: 
                0.700% del SBC. <br><br>

                <h4><strong>Seguro de invalidez y vida</strong></h4>

                Este seguro se cubre por ambas partes, tanto patrón como trabajador. Corresponde al trabajador: 0.625% del SBC y corresponde al 
                patrón: 1.75% del SBC.<br><br>

                <h4><strong>Seguro de retiro, cesantía en edad avanzada y vejez</strong></h4>

                El patrón debe aportar, tanto para el retiro como para la vejez, una cuota de 6.150% del salario base de cotización del trabajador. <br><br>

                <strong>Recuerda:</strong> a partir de enero de 2023 estas aportaciones patronales aumentan de manera gradual. En ese sentido, debes fijarte en la tabla 
                establecida del Salario Base de Cotización del trabajador en la Ley del Seguro Social.<br><br>


                <table class="table text-center">
                  <thead>
                    <tr>
                      <th scope="col">SALARIO BASE DE COTIZACION DEL TRABAJADOR</th>
                      <th scope="col">COSTO PATRONAL 2023</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr> 
                      <td>1.0 SM <strong style="color:red;">*</strong></td>
                      <td>3.150 %</td>
                    </tr>
                    <tr>
                      <td>1.01 SM a 1.50 UMA <strong style="color:red;">**</strong></td>
                      <td>3.281 %</td>
                    </tr>
                    <tr>
                      <td>1.51 a 2.00 UMA</td>
                      <td>3.575 %</td>
                    </tr>
                    <tr>
                      <td>2.01 a 2.50 UMA</td>
                      <td>3.751 %</td>
                    </tr>
                    <tr>
                      <td>2.51 a 3.00 UMA</td>
                      <td>3.869 %</td>
                    </tr>
                    <tr>
                      <td>3.01 a 3.50 UMA</td>
                      <td>3.953 %</td>
                    </tr>
                    <tr>
                      <td>3.51 a 4.00 UMA</td>
                      <td>4.016 %</td>
                    </tr>
                    <tr>
                      <td>4.01 UMA en adelante</td>
                      <td>4.241 %</td>
                    </tr>

                  </tbody>
                </table>

                <strong style="color:red;">*</strong> Salario Mínimo <br>
                <strong style="color:red;">**</strong> Unidad de Medida y Actualización<br><br>


                <h4><strong>Seguro de guarderías y prestaciones sociales</strong></h4>
                En el caso del seguro de guarderías y prestaciones sociales, el patrón debe cubrir el 1% adicional al salario base de cotización que tiene el trabajador.<br><br>
                <h4><strong>Cómo se calcula para salario mínimo</strong></h4>
                Para el año 2023 quedó establecido el salario mínimo para la República Mexicana en $207.44 para el Área General. En la Zona Libre de la Frontera Norte,compuesta por 43 municipios de los estados de Baja California, Sonora, Chihuahua, Coahuila, Nuevo León y Tamaulipas, el pago mínimo diario fijado es de $312.41.<br><br>
                Vamos a tomar de ejemplo el sueldo diario en $207.44 para Julio, quien cumplió un año de antigüedad. Los datos a tomar en cuenta son los siguientes: <br><br>
                <strong>- 12 días de vacaciones.</strong><br>
                <strong>- Una prima vacacional de 25%.</strong><br>
                <strong>- 15 días de aguinaldo.</strong><br><br>
                Ahora, para establecer el SBC necesitamos multiplicar el salario diario x factor de Integración.<br><br>
                El salario diario incluye los pagos realizados en efectivo de acuerdo a las horas trabajadas, gratificaciones, alimentación, habitación y comisiones, entre otros.<br><br>
                Si el salario del empleado es menor al salario mínimo aplicable, se toma el valor del salario mínimo como base para el cálculo de la cuota. Por el contrario, si el salario supera la suma de UMA x 25 veces, se tomará éste último valor para el cálculo de la cuota.<br><br>
                <div class="text-center"><strong>Salario Base de Cotización = (Salario anual total) / 365</strong></div>
                <div class="text-center"><strong>SBC = 365 + 12 días de vacaciones *25% (prima vacacional) + 15 (aguinaldo) / 365</strong></div>
                <div class="text-center"><strong>SBC = 383 / 365</strong></div>
                <div class="text-center"><strong>SBC = 1.049 (monto a tomar como factor de integración)</strong></div><br><br>
                Retomando, el salario de Julio es de $207.44 MXN diarios, al multiplicar este monto por el factor de integración (1.049) obtenemos su Salario Base de Cotización, cuyo resultado es igual a <strong>$217.6 MXN</strong> al día. <br><br>
                Por consiguiente, Julio tendrá registrado ante el IMSS, <strong>$217.6 MXN</strong> como salario diario.<br><br>
                Ahora bien, conforme a lo establecido en la Ley del Seguro Social, ante el pago de salario mínimo el patrón debe asumir el pago correspondiente. <br><br>
                <div class="text-center"><strong>Artículo 36:</strong><i>“Corresponde al patrón pagar íntegramente la cuota señalada para los trabajadores, en los casos en que éstos perciban como cuota diaria el salario mínimo”</i>.</div> <br>
                También puedes revisar la Ley Federal del Trabajo. Ésta establece en su artículo 97 que: Los salarios mínimos no podrán ser objeto de compensación, descuento o reducción. <br><br>
                <h4><strong>Conclusión</strong></h4><br>
                Con CHC Empresarial el cálculo de cuotas del IMSS lo hacemos en segundos gracias a nuestras herramientas e información de cada uno de nuestros colaboradores.<br><br>
                Para ello, hay que estar atento a la actualización anual de las tablas para el cálculo de las cuotas patronales de cesantía en edad avanzada; la cual tiene un incremento hasta el 2030. <br><br>
                No sólo cambiaron las cuotas del IMSS, así que muy pendiente con la nueva versión del SUA. Debes actualizar la prima de riesgo de trabajo del IMSS y prestar atención a las modificaciones de salarios por el aumento de las vacaciones a partir de 2023.<br><br>
                Podemos ayudarte a agilizar esta labor de cálculo con el uso de nuestras herramientas y también ofrecemos asesoría más el servicio de maquila de nómina. Contáctanos para conocer el alcance de nuestros servicios.</p>
                
                <div class="read-more">
                  <a href="https://wa.link/1gea46">Accede a una asesoria profesional...!</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            

          </div><!-- End blog entries list -->

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>