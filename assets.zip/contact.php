<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Contactanos</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Contactanos</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section id="hero1">
        <div class="text-center" data-aos="fade-up">
            <img src="./assets/img/contactanos.jpg" alt="">
        </div>
    </section>

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 text-center">
            <h3>Solicita una <span>Asesoría...!</span></h3>
          </div>
          <div class="col-lg-6 text-center">
            <a class="cta-btn align-middle" href="https://wa.link/1gea46">Realiza una consulta...!</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Contact Section ======= -->
    <div class="map-section">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d505.9390852539104!2d-93.12096744890508!3d16.75960287073199!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85ecd8ed9a905831%3A0x6ceeb85bf4907f00!2sSexta%20Pte.%20Nte.%20731%2C%20Col.%20Centro%2C%20Col%C3%B3n%2C%2029037%20Tuxtla%20Guti%C3%A9rrez%2C%20Chis.%2C%20Mexico!5e0!3m2!1sen!2sec!4v1708080916505!5m2!1sen!2sec" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    <section id="contact" class="contact">
      <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">

          <div class="col-lg-10">

            <div class="info-wrap">
              <div class="row">
                <div class="col-lg-4 info">
                  <i class="bi bi-geo-alt"></i>
                  <h4>Dirección:</h4>
                  <p>Sexta Nte. #731, Piso 2, <br>Tuxtla Gutierrez.<br>Chiapas, Mexico</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-envelope"></i>
                  <h4>Email:</h4>
                  <p>contacto@triunfoactivo.com</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-phone"></i>
                  <h4>Llamanos:</h4>
                  <p>+52 961 848 1613</p>
                </div>
              </div>
            </div>

          </div>

        </div>

        

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>