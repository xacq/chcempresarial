<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Asesoria Fiscal </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image2 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">ASESORIA FISCAL</h3><br>
              <p data-aos="fade-up">
              Cada día, la carga fiscal es mayor para las empresas volviéndose un grave problema si no se lleva de la manera adecuada, es por ello que en CHC Empresarial te asesoramos para que cumplas en tiempo y forma con tus obligaciones.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Al iniciar un nuevo trabajo</h4>
                  <p>"Es importante conocer las obligaciones fiscales que implica un nuevo empleo, como la retención de impuestos sobre la renta (ISR) y las aportaciones a la seguridad social.."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Al recibir un finiquito</h4>
                  <p>"Cuando terminas una relación laboral, es importante revisar que el finiquito esté correctamente calculado y que se te hayan pagado todas las obligaciones fiscales."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Al contratar nuevos empleados</h4>
                  <p>"Las empresas deben cumplir con diversas obligaciones fiscales al contratar nuevos empleados, como darlos de alta en el IMSS y el SAT."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Al realizar el pago de nóminas</h4>
                  <p>"Es importante calcular correctamente las retenciones de impuestos sobre la renta (ISR) y las aportaciones a la seguridad social de los empleados."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Al iniciar un negocio propio</h4>
                  <p>"Si decides emprender, un asesor fiscal puede ayudarte a elegir la forma jurídica más adecuada para tu negocio y cumplir con las obligaciones fiscales correspondientes.."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Otras razones para acceder a la <strong style="color: #f03c02;">ASESORIA FISCAL</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Si la empresa cambia su forma jurídica o realiza una fusión o adquisición, es necesario contar con asesoría fiscal para cumplir con las obligaciones correspondientes.</li>
                  <li>Las empresas deben presentar diversas declaraciones fiscales de forma periódica, como la declaración anual de ISR y la declaración de IVA.</li>
                  <li>En caso de que la empresa sea auditada por el SAT, un asesor fiscal puede ayudarte a defender tus intereses y evitar multas o sanciones..</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>