<?php 
  include('./cabecera.php');
?>
<main id="main">
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center">
      <h2>NOM 035 en México: ¿Qué es y cómo implementarla?</h2> <!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
    </div>
  </div>
</section>
<!-- End Breadcrumbs -->

<!-- =================================== Inicio de Section para el contenido de una NOTICIA ========================================== -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center">
<!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-2.jpg" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br>
<!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
              <br><br><br>
              <h1 class="entry-title">
                <a href="blog-2.php">
                NOM 035 en México: ¿Qué es y cómo implementarla?<!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a> 
              </h1>
<!-- ************* AQUI COLOCO YA EL CONTENIDO DEL BLOG***************-->
              <div class="entry-content">
                <br>
                <p>

                Ante el incremento de casos de estrés laboral en México, fue necesario implementar la NOM 035 en el país como un marco 
                regulatorio fundamental para identificar, analizar y prevenir los factores de riesgo psicosocial en el trabajo. Teniendo 
                en cuenta que, según la Encuesta Nacional de Salud y Nutrición (ENSANUT), citada en Forbes México, el 75 % de los empleados 
                mexicanos perciben su trabajo como una fuente de estrés.<br><br>
                Adicionalmente, de acuerdo a un estudio de la Universidad Nacional Autónoma de México, 85 % de las organizaciones mexicanas 
                no tienen las condiciones adecuadas para que sus colaboradores tengan un balance entre vida personal y trabajo, lo cual 
                propicia trastornos físicos y psicológicos.<br><br>
                En respuesta a esta necesidad, la Norma Oficial Mexicana NOM-035 se ha vuelto esencial para garantizar la salud y el bienestar 
                de los empleados, sobre todo en entornos laborales de constante crecimiento y transformación. En este artículo te explicaremos 
                qué es la NOM 035 y para qué sirve. Además, te proporcionaremos un conjunto de directrices claras para mejorar las condiciones 
                laborales y promover un entorno de trabajo saludable y seguro.<br>


                <h4><strong>¿Qué es la NOM 035?</strong></h4><br>

                La NOM 035 es una de las Normas Oficiales Mexicanas de Seguridad y Salud en el Trabajo, establecida por la Secretaría del Trabajo y Previsión Social (STPS) en México. Su principal objetivo es identificar, analizar y prevenir los factores de riesgo psicosocial en los lugares de trabajo, con el fin de promover ambientes laborales seguros y sanos para los empleados.<br><br>
                Esta normativa se enfoca en los aspectos del entorno laboral que pueden afectar la salud mental, emocional y física de los trabajadores, como el estrés laboral, la violencia laboral, la carga de trabajo, la falta de control sobre las tareas, la comunicación deficiente, entre otros. Reconoce que estos factores pueden tener un impacto significativo en el bienestar de los empleados y, a su vez, en la productividad y eficiencia de las empresas.<br><br>
                La NOM 035 se aplica en todo el país y varía según el tamaño de la empresa, dividiéndose en tres categorías: aquellos con hasta 15 trabajadores, entre 16 y 50 trabajadores, y más de 50 trabajadores.<br><br>

                <h4><strong>¿Cuáles son las 2 etapas de la NOM 035?</strong></h4><br>

                Cabe resaltar que es una normativa relativamente nueva que ha sido implementada en dos fases. La primera fase comenzó el 23 de octubre de 2019, enfocada en establecer políticas, medidas preventivas y la identificación de los trabajadores expuestos a eventos traumáticos severos.<br><br>
                La segunda fase entró en vigor el 23 de octubre de 2020. En esta etapa, se llevó a cabo la identificación y análisis de los factores de riesgo psicosocial, se evaluó el ambiente organizacional, y se establecieron medidas y acciones para controlar estos riesgos. Además, se implementaron exámenes médicos y se llevaron registros correspondientes para monitorear y mantener la salud y el bienestar de los trabajadores.<br><br>

                <h4><strong>¿Para qué sirve la NOM 035?</strong></h4><br>

                Es importante destacar que la NOM 035 no solo tiene implicaciones legales para las empresas, sino que también busca crear conciencia sobre la importancia de la salud mental en el trabajo y fomentar una cultura organizacional que valore el bienestar integral de los trabajadores.<br><br>
                En este sentido, su implementación no solo es un requisito normativo, sino también una oportunidad para mejorar la calidad de vida laboral y el desempeño de los empleados. Dicho esto, te diremos qué efectos positivos se generan por cumplir con la norma 035 en tu empresa:<br><br>

                <p><strong>Promoción del bienestar laboral</strong></p>

                La NOM 035 contribuye a crear un ambiente laboral más saludable y seguro para los empleados. Esta norma puede reducir el estrés laboral, mejorar la satisfacción laboral y aumentar el bienestar emocional y mental de los trabajadores.<br><br>

                <p><strong>Mejora del clima laboral</strong></p>
                Al abordar aspectos como la carga de trabajo, la comunicación deficiente o la falta de control sobre las tareas, la implementación de la NOM 035 puede mejorar el clima laboral en general. Un ambiente laboral positivo y colaborativo puede fomentar la motivación, la productividad y el compromiso de los empleados.<br><br>

                <p><strong>Reducción del ausentismo y la rotación de personal</strong></p>
                Al mejorar las condiciones laborales y reducir los factores de riesgo psicosocial, la NOM 035 puede ayudar a disminuir el ausentismo laboral y la rotación de personal. Los empleados se sentirán más satisfechos y comprometidos, lo que puede llevar a una mayor retención de talento y una menor necesidad de reclutamiento y entrenamiento de nuevos empleados.<br><br>

                <p><strong>Cumplimiento legal y evitación de sanciones</strong></p>
                Cumplir con la Norma Oficial Mexicana NOM-035 es fundamental para evitar sanciones legales y multas por parte de las autoridades laborales mexicanas. Además, demuestra el compromiso de la empresa con la salud y el bienestar de sus empleados, lo que puede mejorar su reputación y credibilidad tanto dentro como fuera de la organización.<br><br>

                <p><strong>Fortalecimiento de la imagen corporativa</strong></p>
                Una empresa que demuestra preocupación por el bienestar de sus empleados mediante la implementación de la NOM 035 puede mejorar su imagen corporativa y su marca empleadora. Esto puede atraer a talentos más calificados y generar una mayor confianza y lealtad entre los clientes y otros stakeholders.<br><br>

                En resumen, la implementación de la NOM 035 no solo es una obligación legal, sino también una oportunidad para mejorar la calidad de vida laboral, promover un ambiente de trabajo positivo y fortalecer la reputación y competitividad de la empresa en el mercado.<br><br>

                <h4><strong>¿Cómo se aplica la NOM 035?</strong></h4><br>

                La NOM 035 establece una serie de obligaciones para los empleadores, que implica la participación activa de los trabajadores, los líderes de equipo y el Departamento de Recursos Humanos de la empresa. Para ello, se deben llevar a cabo las siguientes acciones:<br><br>

                <h5><strong>1. Fortalecimiento de la imagen corporativa</strong></h5><br>
                Este principal requisito de la NOM 035 implica identificar y analizar los diversos factores de riesgo psicosocial presentes en el entorno de trabajo que pueden afectar la salud mental, emocional y física de los empleados.<br><br>
                El artículo 43 del Reglamento Federal de Seguridad y Salud en el Trabajo indica que, en relación con los factores de riesgo psicosocial de la NOM 035, “los patrones deberán identificar y analizar los puestos de trabajo con riesgo psicosocial por la naturaleza de sus funciones o el tipo de jornada laboral”.<br><br>
                Para recopilar información sobre los factores de riesgo psicosocial, el área de recursos humanos puede utilizar una variedad de métodos y herramientas de clima laboral, como cuestionarios específicos sobre estrés laboral, entrevistas individuales o grupales con empleados, observación directa del ambiente de trabajo y revisión de registros de incidentes y quejas previas.<br><br>
                Es importante involucrar a los empleados en el proceso de evaluación, ya que pueden proporcionar información valiosa sobre sus experiencias y percepciones en el trabajo. La participación activa de los trabajadores puede ayudar a identificar problemas que de otra manera podrían pasar desapercibidos y aumentar la aceptación de las medidas correctivas propuestas.<br><br>

                <p><strong>Evaluación constante y personalizada</strong></p>
                Según la NOM 035, la evaluación debe llevarse a cabo regularmente y considerar las particularidades individuales de los trabajadores, como su edad, género, experiencia laboral y otras características relevantes. En otras palabras, la evaluación no debe ser un proceso estático o generalizado, sino que debe adaptarse a las necesidades y circunstancias específicas de cada empleado, reconociendo que diferentes personas pueden enfrentar distintos desafíos en el entorno laboral.<br><br>
                Una vez recopilados los datos, es importante analizarlos cuidadosamente para identificar patrones, tendencias y áreas en común. Esto puede implicar el uso de herramientas estadísticas y de análisis cualitativo para entender mejor la naturaleza y la magnitud de los riesgos psicosociales presentes en la organización.<br><br>

                <h5><strong>2. Desarrollar políticas de seguridad y salud mental</strong></h5><br>
                Basándose en los resultados de la evaluación inicial, es importante desarrollar políticas y procedimientos claros para abordar y prevenir los riesgos psicosociales en el trabajo. La implementación exitosa de la NOM 035 incluye políticas de prevención de acoso laboral, programas de gestión del estrés laboral, protocolos para el manejo de conflictos, entre otros.<br><br>
                Además de establecer políticas reactivas para abordar problemas una vez que surjan, es esencial incluir medidas preventivas para mitigar estos riesgos y promover un ambiente laboral sano. Asimismo, establecer lineamientos para la atención y seguimiento de los casos relacionados con estos factores.<br><br>

                <h5><strong>3. Comunicar el programa a los trabajadores</strong></h5><br>
                Fomentar una cultura de apertura y comunicación en la organización es fundamental para el éxito de la implementación de la NOM 035. Los líderes de recursos humanos deben comunicar claramente la importancia de la normativa, los objetivos de la empresa en relación con el bienestar de los empleados y los recursos disponibles para apoyar a los trabajadores.<br><br>
                
                <h5><strong>4. Capacitar a los empleados y líderes de equipo</strong></h5><br>
                Como HR Manager, debes asegurar que todo el personal, desde la alta dirección hasta los empleados de nivel operativo, esté educado sobre los diferentes factores de riesgo, cómo identificarlos y cómo pueden afectar su salud y bienestar en el trabajo.<br><br>
                Como parte del plan de acción de la NOM 035, los empleados deben ser capacitados para reconocer las señales de alerta de problemas relacionados con la salud mental y física, tanto en ellos mismos como en sus compañeros. Esto puede incluir cambios en el comportamiento, el rendimiento laboral o el bienestar emocional.<br><br>

                <h5><strong>5. Evaluar la efectividad de las medidas implementadas</strong></h5><br>
                Es necesario establecer un sistema de monitoreo continuo para evaluar cómo afecta la NOM 035 a los trabajadores y realizar ajustes según sea necesario. Esto puede incluir la realización periódica de encuestas de clima laboral, la revisión de indicadores de salud y bienestar, y el análisis de incidentes relacionados con los riesgos psicosociales.<br><br>
                El objetivo de aprender cómo se evalúa la NOM 035 es revisar si las medidas implementadas están teniendo el impacto deseado en la reducción de los riesgos psicosociales y la mejora del ambiente laboral. Basándose en los resultados del monitoreo, se pueden identificar áreas específicas que requieren atención adicional o mejoras.<br><br>
                En pocas palabras, el monitoreo y seguimiento son procesos esenciales para garantizar que las medidas aplicadas en el marco de la NOM 035 sean efectivas y se ajusten a las necesidades cambiantes de la organización y sus empleados.<br><br>
  
                <h5><strong>¿Qué pasa si una empresa no aplica la NOM 035?</strong></h5>
                Si una empresa incumple con los requisitos de la NOM 035, puede enfrentar diversas consecuencias legales y sanciones impuestas por las autoridades de gobierno mexicanas, que pueden incluir: <br><br>

                <p><strong>- Multas</strong></p>
                Las autoridades laborales en México pueden imponer multas y sanciones a las empresas que no cumplan con la normativa. Estas multas pueden ser significativas y aumentar con el tiempo si la empresa continúa sin cumplir.<br><br>

                <p><strong>- Problemas legales</strong></p>
                La falta de cumplimiento con la NOM 035 puede llevar a problemas legales para la empresa. Esto podría incluir demandas de los trabajadores por condiciones laborales inseguras o dañinas para la salud mental, así como investigaciones por parte de las autoridades laborales.<br><br>

                <p><strong>- Problemas de retención y reclutamiento</strong></p>
                Un ambiente laboral poco saludable puede afectar la moral de los empleados y su satisfacción laboral, lo que a su vez puede llevar a problemas de retención de talento. Los empleados pueden buscar oportunidades laborales en empresas que ofrezcan un ambiente más seguro.<br><br>

                <p><strong>- Impacto en la productividad</strong></p>
                Los problemas relacionados con el estrés laboral, el acoso o la falta de apoyo pueden afectar la productividad de los empleados. La falta de cumplimiento con la NOM 035 puede contribuir a un ambiente laboral poco saludable que reduce la eficiencia y el rendimiento general de la empresa.<br><br>
                
                Ahora que entiendes qué dice la NOM 035 y a qué obliga a las empresas en México, puedes comprender que esta normativa representa un compromiso con el bienestar y la salud mental de los empleados. Al seguir las pautas y recomendaciones proporcionadas en este artículo, puedes cultivar un ambiente laboral seguro, saludable y productivo para tu capital humano. De esta manera, no solo se fortalece la reputación de la empresa, sino que también se impulsa el rendimiento y la satisfacción de los trabajadores.<br><br>

                </p>
                
                <div class="read-more">
                  <a href="https://wa.link/1gea46">Accede a una asesoria profesional...!</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            

          </div><!-- End blog entries list -->

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>