<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Defensa Laboral </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image3 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">DEFENSA LABORAL</h3><br>
              <p data-aos="fade-up">
              Somos expertos y estamos siempre acompañados de un equipo de profesionales apasionados por la materia, para brindarle la satisfacción y seguridad que usted se merece. Nos colocamos de los dos lados, patrón o trabajador.  Por parte del patrón te asesoramos, el servicio puede ser preventivo o correctivo.  Como trabajador te ayudamos a defender todos tus derechos.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Despido injustificado</h4>
                  <p>"Si te despiden sin causa justificada o sin el pago de las indemnizaciones correspondientes, es importante contar con la asesoría de un abogado especializado en derecho laboral."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Incumplimiento de las obligaciones laborales</h4>
                  <p>"Si tu patrón no cumple con las obligaciones que le corresponden por ley, como el pago del salario, el aguinaldo, las vacaciones, etc., puedes recurrir a la defensa laboral para que se respeten tus derechos."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Discriminación laboral</h4>
                  <p>"Si eres víctima de discriminación en el trabajo por motivos de género, raza, religión, discapacidad, etc., puedes solicitar la defensa laboral para que se investiguen los hechos y se tomen las medidas necesarias."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Mobbing y acoso laboral</h4>
                  <p>"Si sufres mobbing o acoso por parte de tus compañeros de trabajo o superiores jerárquicos, puedes contar con la defensa laboral para que se ponga fin a esta situación y se te proteja de cualquier daño."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Accidentes de trabajo</h4>
                  <p>"Si sufres un accidente de trabajo, la defensa laboral puede ayudarte a obtener la atención médica adecuada, la indemnización correspondiente y la reinstalación en tu puesto de trabajo."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Enfermedades de trabajo</h4>
                  <p>"Si padeces una enfermedad de trabajo, la defensa laboral puede ayudarte a obtener el reconocimiento de la enfermedad como de origen laboral y la correspondiente incapacidad."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Instituciones para acceder a <strong style="color: #f03c02;">DEFENSA LABORAL</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Procuraduría Federal de la Defensa del Trabajo (PROFEDET): Es un organismo público que ofrece asesoría y representación jurídica gratuita a los trabajadores en caso de conflictos con sus patrones.</li>
                  <li>Juntas de Conciliación y Arbitraje: Son los órganos jurisdiccionales encargados de resolver los conflictos entre trabajadores y patrones.</li>
                  <li>Sindicatos: Los sindicatos pueden brindar apoyo y defensa a sus afiliados en caso de problemas laborales.</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>