<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Noticias</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Blog</li>
          </ol>
        </div>
      </div>
    </section><!-- End Breadcrumbs -->
  <!-- =================================== Inicio de Section para un BLOG / NOTICIA ========================================== -->
    <section id="blog" class="blog" style="padding:0px !important;">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center"><!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-1.jpg" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br><br>
              <h2 class="entry-title"><!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                <a href="blog-1.php"> <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                  Paso a paso para el cálculo de cuotas del IMSS <!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a>
              </h2>
              <div class="entry-content"><!-- ************* AQUI COLOCO UNA INTRODUCCION DEL BLOG ***************-->
                <p>
                El cálculo de cuotas del IMSS tuvo para este 2023 varios ajustes a realizar progresivamente. 
                Las también conocidas cuotas obrero patronales representan el total de dinero que se aporta al 
                Instituto Mexicano del Seguro Social (IMSS) por los trabajadores y patrones; más la cuota social 
                que aporta el gobierno mexicano...
                </p>
                <div class="read-more"><!-- ************* AQUI COLOCO EL LINK HACIA LA PAGINA CREADA CON El CONTENIDO DEL BLOG ***************-->
                  <a href="blog-1.php">  <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                    Leer más...!
                  </a>
                </div>
              </div>
            </article><!-- End blog entry -->
          </div><!-- End blog entries list -->
        </div>
      </div>
    </section><!-- End Blog Section -->
<!-- =================================== FIN Blog Section ========================================== -->
<!-- =================================== Inicio de Section para un BLOG / NOTICIA ========================================== -->
  <section id="blog" class="blog" style="padding:0px !important;">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center"><!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-2.jpg" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br><br>
              <h2 class="entry-title"><!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                <a href="blog-2.php"> <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                NOM 035 en México: ¿Qué es y cómo implementarla? <!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a>
              </h2>
              <div class="entry-content"><!-- ************* AQUI COLOCO UNA INTRODUCCION DEL BLOG ***************-->
                <p>
                Ante el incremento de casos de estrés laboral en México, fue necesario implementar la NOM 035 en el país como un 
                marco regulatorio fundamental para identificar, analizar y prevenir los factores de riesgo psicosocial en el trabajo. 
                Teniendo en cuenta que, según la Encuesta Nacional de Salud y Nutrición (ENSANUT), citada en Forbes México, el 75 % 
                de los empleados mexicanos perciben su trabajo como una fuente de estrés....
                </p>
                <div class="read-more"><!-- ************* AQUI COLOCO EL LINK HACIA LA PAGINA CREADA CON El CONTENIDO DEL BLOG ***************-->
                  <a href="blog-2.php">  <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                    Leer más...!
                  </a>
                </div>
            </div>
          </article><!-- End blog entry -->
        </div><!-- End blog entries list -->
      </div>
    </div>
  </section><!-- End Blog Section -->
<!-- =================================== FIN Blog Section ========================================== -->
<!-- =================================== Inicio de Section para un BLOG / NOTICIA ========================================== -->
  <section id="blog" class="blog" style="padding:0px !important;">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center"><!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-3.jpg" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br><br>
              <h2 class="entry-title"><!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                <a href="blog-3.php"> <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                Control Financiero y Eficiencia: Apuesta por la Máquila de Nómina<!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a>
              </h2>
              <div class="entry-content"><!-- ************* AQUI COLOCO UNA INTRODUCCION DEL BLOG ***************-->
                <p>
                Conoce la importancia de contar con un buen control financiero y la implementación de un sistema de nóminas 
                dentro de tu empresa.  El control financiero es fundamental para cualquier organización, empresa o entidad, 
                ya que contar con un sistema eficaz para la gestión de las finanzas impactará en su éxito a largo plazo...
                </p>
                <div class="read-more"><!-- ************* AQUI COLOCO EL LINK HACIA LA PAGINA CREADA CON El CONTENIDO DEL BLOG ***************-->
                  <a href="blog-3.php">  <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                    Leer más...!
                  </a>
                </div>
            </div>
          </article><!-- End blog entry -->
        </div><!-- End blog entries list -->
      </div>
    </div>
  </section><!-- End Blog Section -->
<!-- =================================== FIN Blog Section ========================================== -->
<!-- =================================== Inicio de Section para un BLOG / NOTICIA ========================================== -->
  <section id="blog" class="blog" style="padding:0px !important;">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 entries">
            <article class="entry">
              <div class="text-center"><!-- ************* AQUI COLOCO LA UBICACION DE LA GRAFICA ***************-->
                <img src="assets/img/blog/blog-4.webp" alt="" height="300px" > <!-- ************* PATH A LA GRAFICA DEL BLOG ***************-->
              </div><br><br>
              <h2 class="entry-title"><!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG ASI COMO EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                <a href="blog-4.php"> <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                ¿Cómo optimizar el control de recursos humanos? 5 aspectos claves<!-- ************* AQUI COLOCO EL TEMA PRINCIPAL DEL BLOG***************-->
                </a>
              </h2>
              <div class="entry-content"><!-- ************* AQUI COLOCO UNA INTRODUCCION DEL BLOG ***************-->
                <p>
                Alinea el crecimiento profesional de tus empleados y el desarrollo de la organización con estas 5 claves para el 
                control de recursos humanos.  El control de recursos humanos es fundamental para el éxito de cualquier empresa 
                debido a su importancia en el desarrollo y sostenibilidad empresarial, al ser el pilar que impulsa la cultura 
                corporativa, fomenta la innovación y facilita la adaptación a los cambios...
                </p>
                <div class="read-more"><!-- ************* AQUI COLOCO EL LINK HACIA LA PAGINA CREADA CON El CONTENIDO DEL BLOG ***************-->
                  <a href="blog-4.php">  <!-- ************* EL ACCESO A LA PAGINA CON EL CONTENIDO ***************-->
                    Leer más...!
                  </a>
                </div>
            </div>
          </article><!-- End blog entry -->
        </div><!-- End blog entries list -->
      </div>
    </div>
  </section><!-- End Blog Section -->
<!-- =================================== FIN Blog Section ========================================== -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>