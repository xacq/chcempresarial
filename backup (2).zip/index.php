<?php 
  include('./cabecera.php');
  if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $email = trim($_POST["email"]);

    // Create the email content
    $email_content = "Email: $email\n";

    // Send the email
    $to = "capitalhumano@triunfoactivo.com"; // Cambia "tu-correo@gmail.com" por tu dirección de correo electrónico
    $subject = "Nuevo suscriptor";
    $headers = "From: $email";

    if (mail($to, $subject, $email_content, $headers)) {
        
    } else {
        echo "Error: No se pudo enviar el correo electrónico. Por favor, inténtalo de nuevo más tarde.";
    }
} else {
    echo "Error: Método de solicitud no válido.";
}
?>

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(assets/img/slide/slide-1.jpg);">
          <div class="carousel-container text-center">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <img src="./assets/img/titulo1.png" alt="TU TRANQUILIDAD ES NUESTRA PRIORIDAD" height="150px" >
              <div class="text-center"><a href="./about.php" class="btn-get-started">Saber más...!</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-2.jpg);">
          <div class="carousel-container text-center">
            <div class="carousel-content animate__animated animate__fadeInUp">
            <img src="./assets/img/titulo1.png" alt="TU TRANQUILIDAD ES NUESTRA PRIORIDAD" height="150px" >
              <div class="text-center"><a href="./services.php" class="btn-get-started">Nuestros servicios...!</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-3.jpg);">
          <div class="carousel-container text-center">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <img src="./assets/img/titulo1.png" alt="TU TRANQUILIDAD ES NUESTRA PRIORIDAD" height="150px" >
              <div class="text-center"><a href="./contact.php" class="btn-get-started">Contáctanos...!</a></div>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section><!-- End Hero -->

  <main id="main">


    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h3>Conoce cuales son nuestros servicios en <span>Asesoría...!</span></h3>
          </div>
        </div>
      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="row">
        <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up">
                <div class="icon">
                    <i class="bi bi-briefcase"></i>
                    <!-- Nuevo div para el texto -->
                    <div class="icon-text">Parte fundamental en el éxito empresarial es el factor humano, por ello garantizamos que nuestros clientes lleven la administración del personal de manera ordenada y de acuerdo a las leyes vigentes en nuestro país.</div>
                </div>
                <h4 class="title"><a href="">Asesoria Laboral</a></h4>
            </div>
        </div>

          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="50">
              <div class="icon">
                <i class="bi bi-card-checklist"></i>
                    <!-- Nuevo div para el texto -->
                    <div class="icon-text">Somos expertos y estamos siempre acompañados de un equipo de profesionales apasionados por la materia, para brindarle la satisfacción y seguridad que usted se merece. Nos colocamos de los dos lados, patrón o trabajador.</div>
                </div>
              <h4 class="title"><a href="">Defensa Laboral</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="50">
              <div class="icon">
                <i class="bi bi-bar-chart"></i>
                    <!-- Nuevo div para el texto -->
                    <div class="icon-text">Apoyamos al procesamiento y cálculo de prestaciones económicas que por concepto de salarios y prestaciones laborales perciben los trabajadores de una empresa, así como los cálculos y procesamientos de impuestos.</div>
              </div>
              <h4 class="title"><a href="">Maquila de Nómina</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="50">
            <div class="icon">
                <i class="bi bi-list-columns"></i>
                    <!-- Nuevo div para el texto -->
                    <div class="icon-text">Asesoramos sobre los beneficios al que tienen derecho, por haber cotizado durante su vida laboral, o de ser la o el beneficiario de una persona ante ese Instituto, en muchos de los casos se niega tales beneficios, por lo que se acompaña para hacer valer sus derechos.</div>
              </div>
              <h4 class="title"><a href="">Asesoría por pensión ISSSTE</a></h4>
              
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="50">
            <div class="icon">
              <i class="bi bi-person-video3"></i>
                    <!-- Nuevo div para el texto -->
                    <div class="icon-text">Defendemos por la vía legal, ante órganos competentes, dirigidos a personas físicas o morales que han sido vulnerados en sus derechos humanos de contribuyentes, de todos aquellos actos o resoluciones de las diversas autoridades recaudadoras del gobierno existente.</div>
              </div>
              <h4 class="title"><a href="">Defensa Fiscal</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="50">
              <div class="icon">
                <i class="bi bi-calendar4-week"></i>
                      <!-- Nuevo div para el texto -->
                      <div class="icon-text">Cada día, la carga fiscal es mayor para las empresas volviéndose un grave problema si no se lleva de la manera adecuada, es por ello que en CHC Empresarial te asesoramos para que cumplas en tiempo y forma con tus obligaciones.</div>
              </div>              
              <h4 class="title"><a href="">Asesoría Fiscal</a></h4>              
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

<!-- ======= Features Section ======= -->
<section id="features" class="features">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Por que acceder a los <strong style="color: #ff8b00;">Servicios</strong> que proveemos...?</h2>
        </div>

        <div class="row">
          <div class="col-lg-6 mb-6 mb-lg-0" data-aos="fade-right">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">
                  <h4>Compromiso con la justicia social y la promoción del trabajo decente.</h4>
                  
                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-2">
                  <h4>Expertos en mediación y conciliación.</h4>
                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-3">
                  <h4>Conocimiento profundo de las leyes y normas laborales.</h4>

                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-4">
                  <h4>Equipo especializado en derecho laboral y recursos humanos</h4>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-lg-6 ml-auto" data-aos="fade-left" data-aos-delay="50">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <figure>
                  <img src="assets/img/features-1.png" alt="" class="img-fluid">
                </figure>
              </div>
              <div class="tab-pane" id="tab-2">
                <figure>
                  <img src="assets/img/features-2.png" alt="" class="img-fluid">
                </figure>
              </div>
              <div class="tab-pane" id="tab-3">
                <figure>
                  <img src="assets/img/features-3.png" alt="" class="img-fluid">
                </figure>
              </div>
              <div class="tab-pane" id="tab-4">
                <figure>
                  <img src="assets/img/features-4.png" alt="" class="img-fluid">
                </figure>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Our Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Nuestros <strong>Clientes</strong></h2>
          
        </div>

        <div class="row no-gutters clients-wrap clearfix" data-aos="fade-up">

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-7.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-8.png" class="img-fluid" alt="">
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Our Clients Section -->

  </main><!-- End #main -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="footer-top cta">
      <div class="container text-center">
        <div class="col-lg-12 col-md-12 footer-newsletter text-center">
          <h4>Recibe noticias de nuestras actividades</h4>
            <form action="./index.php" method="get">
              <input type="email" name="email">
              <input style="background-color: #ff8b00;" type="submit" value="Subscribete">
            </form>
        </div>
      </div>  
    </section><!-- End Cta Section -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>