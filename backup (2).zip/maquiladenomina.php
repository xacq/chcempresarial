<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Maquila de Nómina </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image5 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">MAQUILA DE NÓMINA</h3><br>
              <p data-aos="fade-up">
              Nuestro servicio consiste en el procesamiento y cálculo de las prestaciones económicas que por concepto de salarios y demás prestaciones laborales perciben los trabajadores de una empresa, así como también cálculos y procesamientos de impuestos Estatales, Federales, de Seguridad Social, INFONAVIT y FONACOT.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Reducción de carga administrativa</h4>
                  <p>"Si la empresa no cuenta con un departamento de Recursos Humanos o si este tiene una carga de trabajo excesiva, la maquila de nómina puede ayudar a aliviar la carga administrativa y liberar tiempo para que el personal se enfoque en otras tareas estratégicas."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Cumplimiento legal</h4>
                  <p>"La gestión de nóminas implica el cumplimiento de diversas obligaciones fiscales y laborales. La maquila de nómina puede ayudar a las empresas a cumplir con estas obligaciones de manera precisa y puntual, evitando multas y sanciones."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Especialización</h4>
                  <p>"Las empresas de maquila de nómina cuentan con personal especializado en el cálculo de nóminas, impuestos y seguridad social. Esto permite a las empresas acceder a un conocimiento y experiencia que no siempre tienen internamente."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Ahorro de costes</h4>
                  <p>"En algunos casos, la maquila de nómina puede resultar más económica que mantener un departamento de Recursos Humanos interno, especialmente para empresas pequeñas o con un bajo volumen de empleados."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Flexibilidad</h4>
                  <p>"La maquila de nómina ofrece flexibilidad a las empresas, ya que pueden adaptar el servicio a sus necesidades específicas, como el número de empleados, la frecuencia de pago o los tipos de nóminas a procesar."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Otras razones para acceder a la <strong style="color: #f03c02;">MAQUILA DE NÓMINA</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Control y seguimiento: Las empresas de maquila de nómina suelen ofrecer herramientas y plataformas online que permiten a las empresas tener un control y seguimiento de sus nóminas en tiempo real.</li>
                  <li>Escalabilidad: La maquila de nómina puede escalarse fácilmente para adaptarse al crecimiento de la empresa, sin necesidad de invertir en infraestructura o contratar personal adicional.</li>
                  <li>Control y seguimiento: Las empresas de maquila de nómina suelen ofrecer herramientas y plataformas online que permiten a las empresas tener un control y seguimiento de sus nóminas en tiempo real.</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>