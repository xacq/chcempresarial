<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Defensa Fiscal </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image4 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">DEFENSA FISCAL</h3><br>
              <p data-aos="fade-up">
              Defendemos por la vía legal, ante órganos competentes, dirigidos a personas físicas o morales que se encuentren o se sientan vulnerados de sus derechos humanos de contribuyentes, de todos aquellos actos o resoluciones de las diversas autoridades recaudadoras de los tres niveles de gobierno existentes.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Cálculo y pago de impuestos</h4>
                  <p>"La empresa o el trabajador pueden necesitar asesoramiento sobre cómo calcular y pagar correctamente los impuestos relacionados con el trabajo, como el Impuesto Sobre la Renta (ISR), el Impuesto al Valor Agregado (IVA) y las cuotas de seguridad social."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Declaraciones fiscales</h4>
                  <p>"La empresa o el trabajador pueden necesitar ayuda para preparar y presentar las declaraciones fiscales relacionadas con el trabajo, como la declaración anual del ISR o la declaración bimestral del IVA."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Cumplimiento de las normas fiscales</h4>
                  <p>"La empresa o el trabajador pueden necesitar asesoramiento sobre cómo cumplir con las normas fiscales vigentes en México, incluyendo las reformas recientes y la jurisprudencia aplicable."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Auditorías fiscales</h4>
                  <p>"Si la empresa o el trabajador es objeto de una auditoría fiscal, puede necesitar representación legal para defender sus derechos e intereses."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-down-arrow"></i>
                  <h4>Juicios fiscales</h4>
                  <p>" Si la empresa o el trabajador es demandado por la autoridad fiscal, puede necesitar representación legal para defenderse en un juicio fiscal."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Otras situaciones para acceder a <strong style="color: #f03c02;">DEFENSA FISCAL</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Despidos: En algunos casos, el despido de un trabajador puede tener consecuencias fiscales para la empresa o el trabajador. La defensa fiscal puede ser necesaria para asegurar que se cumplan las normas fiscales en materia de despidos.</li>
                  <li>Jubilación: La jubilación de un trabajador también puede tener consecuencias fiscales. La defensa fiscal puede ser necesaria para asegurar que el trabajador reciba los beneficios fiscales a los que tiene derecho.</li>
                  <li>Recargos e intereses: Si la empresa o el trabajador tiene una deuda fiscal, puede necesitar representación legal para negociar la reducción de los recargos e intereses.</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>