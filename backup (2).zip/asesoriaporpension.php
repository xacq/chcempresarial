<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Asesoria por Pensión ISSSTE </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image6 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">ASESORIA POR PENSIÓN ISSSTE</h3><br>
              <p data-aos="fade-up">
              Consiste en asesorar sobre los beneficios a que tienen derecho, por el hecho de haber cotizado durante su vida laboral, o de ser la o el beneficiario de una persona ante ese Instituto, en muchos de los casos se niega tales beneficios, por lo que se acompaña al derechohabiente para que por el medio legal, haga valer sus derechos.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Planificación de la jubilación</h4>
                  <p>"Es importante que los trabajadores del sector público afiliados al ISSSTE planifiquen con anticipación su jubilación. Un asesor especializado puede ayudar a calcular la pensión estimada, evaluar las diferentes opciones de retiro y tomar decisiones informadas sobre el momento ideal para jubilarse."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Trámite de la pensión</h4>
                  <p>"El proceso de solicitud de la pensión ISSSTE puede ser complejo y requerir la presentación de diversos documentos. Un asesor puede ayudar a los trabajadores a reunir la documentación necesaria, completar los formularios correctamente y realizar el trámite de manera eficiente."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Resolución de dudas e incidencias</h4>
                  <p>"En ocasiones, pueden surgir dudas o incidencias relacionadas con la pensión ISSSTE, como el cálculo del monto de la pensión, la actualización de datos personales o la resolución de errores en el pago. Un asesor puede ayudar a los pensionados a resolver estas dudas e incidencias de manera eficaz."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Reclamaciones y recursos administrativos</h4>
                  <p>En caso de que un trabajador o pensionado del ISSSTE considere que sus derechos no han sido reconocidos, puede presentar una reclamación o un recurso administrativo. Un asesor puede ayudar a los interesados a preparar y presentar la reclamación o recurso de manera adecuada, aumentando las posibilidades de éxito."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Asesoramiento legal</h4>
                  <p>"En algunos casos, puede ser necesario contar con asesoramiento legal especializado en materia de pensiones del ISSSTE. Un abogado con experiencia en este ámbito puede ayudar a los trabajadores y pensionados a defender sus derechos e intereses."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Cuando se recomienda consultar con un asesor especializado en <strong style="color: #f03c02;">PENSIONES DEL ISSSTE</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Cuando se esté próximo a jubilarse y se desee planificar el proceso de manera adecuada.</li>
                  <li>Cuando se tenga dudas sobre el cálculo de la pensión o los requisitos para acceder a ella.</li>
                  <li>Cuando se tenga dificultades para realizar el trámite de solicitud de la pensión.</li>
                  <li>Cuando se tenga problemas con el pago de la pensión o se haya detectado algún error.</li>
                  <li>Cuando se desee presentar una reclamación o un recurso administrativo relacionado con la pensión.</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>