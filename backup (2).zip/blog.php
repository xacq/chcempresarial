<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Noticias</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Blog</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-12 entries">

            <article class="entry">

              <div class="text-center">
                <img src="assets/img/blog/blog-1.jpg" alt="" height="300px" >
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html">Tema a tratar</a>
              </h2>

              <div class="entry-content">
                <p>
                  Intro al documento
                </p>
                <div class="read-more">
                  <a href="#">Leer más...!</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            

          </div><!-- End blog entries list -->

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>