<?php 
  include('./cabecera.php');
?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Servicios</h2>
          <ol>
            <li><a href="index.php">Inicio</a></li>
            <li>Asesoria Laboral </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= About Us Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container">

        <div class="row no-gutters">
          <div class="image1 col-xl-4 col-md-4 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right"></div>
          <div class="col-xl-8 col-md-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-up">ASESORIA LABORAL</h3><br>
              <p data-aos="fade-up">
              Parte fundamental en el éxito empresarial es el factor humano, por ello garantizamos que nuestros clientes lleven la administración del personal de manera ordenada y de acuerdo a las leyes vigentes en nuestro país.
              </p>
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bi bi-person-check"></i>
                  <h4>Elaboración y revisión de contratos de trabajo</h4>
                  <p>"Tener la capacidad de hacer el bien para nuestros clientes y en el actuar de la empresa día con día."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bx bx-shield"></i>
                  <h4>Gestión de nóminas y seguridad social</h4>
                  <p>"Al ofertar los precios nos preocupamos por la empresa de nuestros clientes."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-lock"></i>
                  <h4>Casos de Despido</h4>
                  <p>"Para los empresarios que nos contratan, pudiendo enfocar sus esfuerzos en el crecimiento de su empresa."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Casos de conflicto laboral</h4>
                  <p>"Al cumplir con las actividades laborales y brindarles la tranquilidad a todos nuestros clientes para su exito."</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="50">
                  <i class="bi bi-graph-up-arrow"></i>
                  <h4>Dudas o consultas sobre la legislación laboral</h4>
                  <p>"Al cumplir con las actividades laborales y brindarles la tranquilidad a todos nuestros clientes para su exito."</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">


        <div class="section-title" data-aos="fade-up">
          <h2>Otras razones para acceder a la <strong style="color: #f03c02;">ASESORIA LABORAL</strong></h2>
          <div class="row">
            <div class="col-8 offset-2">
              <p data-aos="fade-up">
                <ul style="text-align:left">
                  <li>Realizar auditorías laborales: para verificar el cumplimiento de la legislación laboral en la empresa.</li>
                  <li>Diseñar e implementar políticas de Recursos Humanos: para mejorar la gestión del personal en la empresa.</li>
                  <li>Formar a los empleados en materia laboral: para que conozcan sus derechos y obligaciones.</li>
                </ul>
              </p>

            </div>
          </div>

      </div>
    </section><!-- End Our Skills Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
    include('./pie.php');
  ?>

</body>

</html>